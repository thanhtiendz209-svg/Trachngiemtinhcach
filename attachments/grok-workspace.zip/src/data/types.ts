export type PersonalityGroup = "analyst" | "creative" | "social" | "organizer";

export interface PersonalityType {
  id: string;
  name: string;
  slogan: string;
  summary: string;
  description: string;
  group: PersonalityGroup;
  image?: string;
  highlights: string[];
  thinking: string;
  interacting: string;
  deciding: string;
  learning: string;
  strengths: string[];
  improvements: string[];
  careers: string[];
  environment: string;
  note: string;
}

export type QuizKind = "mbti" | "riasec" | "bigfive" | "interest" | "combined";

export interface QuizMeta {
  id: string;
  kind: QuizKind;
  name: string;
  tagline: string;
  description: string;
  duration: string;
  questionCount: number;
  icon: "compass" | "layers" | "spark" | "heart" | "map";
  image: string;
}

export interface QuestionOption {
  label: string;
  scores: Record<string, number>;
}

export interface Question {
  id: string;
  text: string;
  hint?: string;
  options: QuestionOption[];
}

export interface CareerField {
  id: string;
  name: string;
  description: string;
  riasec: string[];
  types: string[];
  icon:
    | "cpu"
    | "pen"
    | "megaphone"
    | "coins"
    | "wrench"
    | "graduation"
    | "heartPulse"
    | "truck"
    | "building"
    | "flask";
  roles: string[];
  skills: string[];
  study: string;
  environment: string;
  note: string;
}

export interface QuizResult {
  quizId: string;
  kind: QuizKind;
  completedAt: string;
  mbti?: string;
  axes?: {
    energy: number;
    sensing: number;
    thinking: number;
    judging: number;
  };
  riasec?: { code: string; scores: Record<string, number> };
  bigfive?: Record<string, number>;
  answers: number[];
}

export interface QuizProgress {
  quizId: string;
  index: number;
  answers: number[];
  updatedAt: string;
}

export interface RiasecType {
  id: string;
  name: string;
  slogan: string;
  summary: string;
  description: string;
  image: string;
  highlights: string[];
  thinking: string;
  interacting: string;
  deciding: string;
  learning: string;
  strengths: string[];
  improvements: string[];
  careers: string[];
  environment: string;
  note: string;
}
