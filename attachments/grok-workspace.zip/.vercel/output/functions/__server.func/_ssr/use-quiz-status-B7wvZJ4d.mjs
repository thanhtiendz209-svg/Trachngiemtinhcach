import { i as __toESM } from "../_runtime.mjs";
import { l as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as hasPartialProgress, f as loadProgress, g as QUIZZES, p as loadResult, u as loadLastResult } from "./router-CWfDjVKO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-quiz-status-B7wvZJ4d.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useLastResult() {
	const [result, setResult] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setResult(loadLastResult());
	}, []);
	return result;
}
function useAllQuizStatus() {
	const [map, setMap] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		const next = {};
		for (const q of QUIZZES) {
			const p = loadProgress(q.id);
			const r = loadResult(q.id);
			next[q.id] = {
				progress: hasPartialProgress(q.id),
				result: Boolean(r),
				index: p?.index ?? 0,
				answered: p?.answers.filter((a) => a >= 0).length ?? 0
			};
		}
		setMap(next);
	}, []);
	return map;
}
//#endregion
export { useLastResult as n, useAllQuizStatus as t };
