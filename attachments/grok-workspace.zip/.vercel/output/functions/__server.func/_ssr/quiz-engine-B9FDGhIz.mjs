import { S as pct, _ as getQuiz, v as questionsFor } from "./router-CWfDjVKO.mjs";
import { r as getPersonality } from "./personalities-Cs8oYZbZ.mjs";
import { t as RIASEC_MAP } from "./riasec-Bmnf9dLm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz-engine-B9FDGhIz.js
function tally(questions, answers) {
	const scores = {};
	questions.forEach((q, i) => {
		const opt = q.options[answers[i] ?? -1];
		if (!opt) return;
		for (const [k, v] of Object.entries(opt.scores)) scores[k] = (scores[k] ?? 0) + v;
	});
	return scores;
}
function pick(scores, a, b) {
	return (scores[a] ?? 0) >= (scores[b] ?? 0) ? a : b;
}
function mbtiFromScores(scores) {
	return {
		type: `${pick(scores, "E", "I")}${pick(scores, "S", "N")}${pick(scores, "T", "F")}${pick(scores, "J", "P")}`,
		axes: {
			energy: pct(scores.E ?? 0, (scores.E ?? 0) + (scores.I ?? 0)),
			sensing: pct(scores.S ?? 0, (scores.S ?? 0) + (scores.N ?? 0)),
			thinking: pct(scores.T ?? 0, (scores.T ?? 0) + (scores.F ?? 0)),
			judging: pct(scores.J ?? 0, (scores.J ?? 0) + (scores.P ?? 0))
		}
	};
}
var R_KEYS = [
	"R",
	"I",
	"A",
	"S",
	"E",
	"C"
];
function riasecFromScores(scores, prefixed = false) {
	const mapped = {};
	for (const k of R_KEYS) mapped[k] = prefixed ? scores[`r${k}`] ?? 0 : scores[k] ?? 0;
	return {
		code: [...R_KEYS].sort((a, b) => (mapped[b] ?? 0) - (mapped[a] ?? 0)).slice(0, 3).join(""),
		scores: mapped
	};
}
function bigfiveFromScores(scores) {
	const keys = [
		"O",
		"C",
		"E",
		"A",
		"N"
	];
	const out = {};
	for (const k of keys) {
		const v = scores[k] ?? 12;
		out[k] = Math.round((v - 4) / 16 * 100);
		out[k] = Math.min(96, Math.max(8, out[k]));
	}
	return out;
}
function scoreQuiz(quizId, answers) {
	const quiz = getQuiz(quizId);
	const questions = questionsFor(quizId);
	if (!quiz || questions.length === 0) return null;
	const scores = tally(questions, answers);
	const base = {
		quizId,
		kind: quiz.kind,
		completedAt: (/* @__PURE__ */ new Date()).toISOString(),
		answers
	};
	if (quiz.kind === "mbti") {
		const m = mbtiFromScores(scores);
		return {
			...base,
			mbti: m.type,
			axes: m.axes
		};
	}
	if (quiz.kind === "riasec" || quiz.kind === "interest") return {
		...base,
		riasec: riasecFromScores(scores, false)
	};
	if (quiz.kind === "bigfive") return {
		...base,
		bigfive: bigfiveFromScores(scores)
	};
	const m = mbtiFromScores(scores);
	return {
		...base,
		mbti: m.type,
		axes: m.axes,
		riasec: riasecFromScores(scores, true)
	};
}
function resultTitle(result) {
	if (result.mbti) return getPersonality(result.mbti) ? `Bạn thuộc nhóm ${result.mbti}` : `Nhóm ${result.mbti}`;
	if (result.riasec) {
		const top = result.riasec.code[0] ?? "I";
		const t = RIASEC_MAP[top];
		return t ? `Xu hướng nổi bật: ${t.name}` : `Mã Holland ${result.riasec.code}`;
	}
	if (result.bigfive) return "Hồ sơ Big Five của bạn";
	return "Hồ sơ của bạn";
}
function resultSubtitle(result) {
	if (result.mbti) return getPersonality(result.mbti)?.name ?? result.mbti;
	if (result.riasec) return `Mã ${result.riasec.code}`;
	return "Chân dung tham khảo";
}
//#endregion
export { resultTitle as n, scoreQuiz as r, resultSubtitle as t };
