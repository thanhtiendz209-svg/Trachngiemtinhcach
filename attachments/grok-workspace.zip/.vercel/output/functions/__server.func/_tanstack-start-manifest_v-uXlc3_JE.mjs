//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-uXlc3_JE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/gioi-thieu",
			"/ho-so",
			"/huong-nghiep",
			"/nhom-tinh-cach",
			"/trac-nghiem",
			"/ket-qua/$quizId"
		],
		preloads: [
			"/assets/index-60AbehFw.js",
			"/assets/useSelector-BcTnCC3_.js",
			"/assets/react-dom-emD310i4.js",
			"/assets/preload-helper-CUvQgJsB.js",
			"/assets/SiteShell-BrHipkRS.js",
			"/assets/root-DLTE-HSj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-60AbehFw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CXKIJcEw.js",
			"/assets/arrow-right-CnspOVhu.js",
			"/assets/Faq-kq9l5t40.js",
			"/assets/QuizPicker-VCOS4AIt.js",
			"/assets/careers-B07Xq60a.js",
			"/assets/Reveal-CEN_sG8-.js",
			"/assets/HollandStrip-CaUi8xqA.js",
			"/assets/TypeGrid-DoL9QThF.js"
		]
	},
	"/gioi-thieu": {
		filePath: "/workspace/src/routes/gioi-thieu.tsx",
		children: void 0,
		preloads: [
			"/assets/gioi-thieu-Dn7MbbZK.js",
			"/assets/Faq-kq9l5t40.js",
			"/assets/Reveal-CEN_sG8-.js"
		]
	},
	"/ho-so": {
		filePath: "/workspace/src/routes/ho-so.tsx",
		children: void 0,
		preloads: [
			"/assets/ho-so-DPkjI0-5.js",
			"/assets/ResultView-C4ZrTK_l.js",
			"/assets/Reveal-CEN_sG8-.js"
		]
	},
	"/huong-nghiep": {
		filePath: "/workspace/src/routes/huong-nghiep.tsx",
		children: ["/huong-nghiep/$careerId", "/huong-nghiep/"],
		preloads: ["/assets/huong-nghiep-BXap494c.js"]
	},
	"/nhom-tinh-cach": {
		filePath: "/workspace/src/routes/nhom-tinh-cach.tsx",
		children: ["/nhom-tinh-cach/$typeId", "/nhom-tinh-cach/"],
		preloads: ["/assets/nhom-tinh-cach-BXap494c.js"]
	},
	"/trac-nghiem": {
		filePath: "/workspace/src/routes/trac-nghiem.tsx",
		children: ["/trac-nghiem/$quizId", "/trac-nghiem/"],
		preloads: ["/assets/trac-nghiem-BXap494c.js"]
	},
	"/huong-nghiep/$careerId": {
		filePath: "/workspace/src/routes/huong-nghiep.$careerId.tsx",
		children: void 0,
		preloads: [
			"/assets/huong-nghiep._careerId-zqN68n3c.js",
			"/assets/careers-B07Xq60a.js",
			"/assets/Reveal-CEN_sG8-.js",
			"/assets/personalities-sN9-MLlv.js",
			"/assets/riasec-BX89nm14.js",
			"/assets/TypeCard-Dd1C7npi.js",
			"/assets/use-quiz-status-Bw0E5BhE.js"
		]
	},
	"/ket-qua/$quizId": {
		filePath: "/workspace/src/routes/ket-qua.$quizId.tsx",
		children: void 0,
		preloads: ["/assets/ket-qua._quizId-pOnwlsVi.js", "/assets/ResultView-C4ZrTK_l.js"]
	},
	"/nhom-tinh-cach/$typeId": {
		filePath: "/workspace/src/routes/nhom-tinh-cach.$typeId.tsx",
		children: void 0,
		preloads: [
			"/assets/nhom-tinh-cach._typeId-B68XfcfV.js",
			"/assets/Reveal-CEN_sG8-.js",
			"/assets/TypePortrait-toP2VQFp.js",
			"/assets/personalities-sN9-MLlv.js",
			"/assets/TypeCard-Dd1C7npi.js"
		]
	},
	"/trac-nghiem/$quizId": {
		filePath: "/workspace/src/routes/trac-nghiem.$quizId.tsx",
		children: void 0,
		preloads: [
			"/assets/trac-nghiem._quizId-1d3-tfil.js",
			"/assets/arrow-right-CnspOVhu.js",
			"/assets/quiz-engine-k9dOpppQ.js"
		]
	},
	"/huong-nghiep/": {
		filePath: "/workspace/src/routes/huong-nghiep.index.tsx",
		children: void 0,
		preloads: [
			"/assets/huong-nghiep.index-VFaxn9mH.js",
			"/assets/careers-B07Xq60a.js",
			"/assets/Reveal-CEN_sG8-.js",
			"/assets/riasec-BX89nm14.js",
			"/assets/use-quiz-status-Bw0E5BhE.js",
			"/assets/HollandStrip-CaUi8xqA.js"
		]
	},
	"/nhom-tinh-cach/": {
		filePath: "/workspace/src/routes/nhom-tinh-cach.index.tsx",
		children: void 0,
		preloads: [
			"/assets/nhom-tinh-cach.index-BLgWJCPu.js",
			"/assets/Reveal-CEN_sG8-.js",
			"/assets/TypeGrid-DoL9QThF.js"
		]
	},
	"/trac-nghiem/": {
		filePath: "/workspace/src/routes/trac-nghiem.index.tsx",
		children: void 0,
		preloads: [
			"/assets/trac-nghiem.index-C_JoxjKj.js",
			"/assets/QuizPicker-VCOS4AIt.js",
			"/assets/Reveal-CEN_sG8-.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
